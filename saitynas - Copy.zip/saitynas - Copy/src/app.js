const express = require('express');
const cors = require('cors');
const pool = require('./config/db');
const apklausaRoutes = require('./routes/apklausaRoutes');
const klausimasRoutes = require('./routes/klausimasRoutes');
const atsakymasRoutes = require('./routes/atsakymasRoutes');
const app = express();
const port = process.env.PORT || 3000;
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');
app.use(cors());
app.use(express.json());

app.use('/api/apklausos', apklausaRoutes);
app.use(
    '/api/apklausos/:apklausaId/klausimai',
    klausimasRoutes
);
app.use(
    '/api/klausimai/:klausimasId/atsakymai',
    atsakymasRoutes
);
app.use(
    '/api-docs',
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec)
);
app.get('/', (req, res) => {
  res.status(200).json({ message: 'Tyrimas REST API veikia' });
});

app.get('/api/test-db', async (req, res) => {
  try {
    const result = await pool.query('SELECT NOW()');

    res.status(200).json({
      message: 'Database connection successful',
      databaseTime: result.rows[0].now,
    });
  } catch (error) {
    console.error('Database connection failed:', error.message);
    res.status(500).json({ error: 'Database connection failed' });
  }
});

app.listen(port, () => {
  console.log(`Tyrimas REST API is running on port ${port}`);
});