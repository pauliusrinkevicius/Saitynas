const pool = require('../config/db');

// GET /api/apklausos
const getAllApklausos = async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM apklausa ORDER BY id'
        );

        res.status(200).json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// GET /api/apklausos/:id
const getApklausaById = async (req, res) => {
    try {
        const { id } = req.params;

        const result = await pool.query(
            'SELECT * FROM apklausa WHERE id = $1',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Apklausa nerasta'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// POST /api/apklausos
const createApklausa = async (req, res) => {
    try {
        const { pavadinimas, aprasymas } = req.body;

        if (!pavadinimas || pavadinimas.trim() === '') {
            return res.status(422).json({
                error: 'Pavadinimas yra privalomas'
            });
        }

        const result = await pool.query(
            `INSERT INTO apklausa (pavadinimas, aprasymas)
             VALUES ($1, $2)
             RETURNING *`,
            [pavadinimas, aprasymas]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// PUT /api/apklausos/:id
const updateApklausa = async (req, res) => {
    try {
        const { id } = req.params;
        const { pavadinimas, aprasymas } = req.body;

        if (!pavadinimas || pavadinimas.trim() === '') {
            return res.status(422).json({
                error: 'Pavadinimas yra privalomas'
            });
        }

        const result = await pool.query(
            `UPDATE apklausa
             SET pavadinimas = $1,
                 aprasymas = $2
             WHERE id = $3
             RETURNING *`,
            [pavadinimas, aprasymas, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Apklausa nerasta'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// DELETE /api/apklausos/:id
const deleteApklausa = async (req, res) => {
    try {
        const { id } = req.params;

        const result = await pool.query(
            'DELETE FROM apklausa WHERE id = $1 RETURNING id',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Apklausa nerasta'
            });
        }

        res.status(204).send();
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

module.exports = {
    getAllApklausos,
    getApklausaById,
    createApklausa,
    updateApklausa,
    deleteApklausa
};