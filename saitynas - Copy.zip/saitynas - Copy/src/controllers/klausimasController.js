const pool = require('../config/db');

// GET /api/apklausos/:apklausaId/klausimai
const getAllKlausimai = async (req, res) => {
    try {
        const { apklausaId } = req.params;

        const result = await pool.query(
            'SELECT * FROM klausimas WHERE apklausa_id = $1 ORDER BY id',
            [apklausaId]
        );

        res.status(200).json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// GET /api/apklausos/:apklausaId/klausimai/:id
const getKlausimasById = async (req, res) => {
    try {
        const { apklausaId, id } = req.params;

        const result = await pool.query(
            `SELECT *
             FROM klausimas
             WHERE id = $1 AND apklausa_id = $2`,
            [id, apklausaId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Klausimas nerastas'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// POST /api/apklausos/:apklausaId/klausimai
const createKlausimas = async (req, res) => {
    try {
        const { apklausaId } = req.params;

        const {
            klausimo_tekstas,
            a_variantas,
            b_variantas,
            c_variantas,
            d_variantas
        } = req.body;

        if (
            !klausimo_tekstas ||
            !a_variantas ||
            !b_variantas ||
            !c_variantas ||
            !d_variantas
        ) {
            return res.status(422).json({
                error: 'Klausimo tekstas ir visi keturi variantai yra privalomi'
            });
        }

        // Patikriname, ar apklausa egzistuoja
        const apklausa = await pool.query(
            'SELECT id FROM apklausa WHERE id = $1',
            [apklausaId]
        );

        if (apklausa.rows.length === 0) {
            return res.status(404).json({
                error: 'Apklausa nerasta'
            });
        }

        const result = await pool.query(
            `INSERT INTO klausimas
                (apklausa_id, klausimo_tekstas,
                 a_variantas, b_variantas, c_variantas, d_variantas)
             VALUES ($1, $2, $3, $4, $5, $6)
             RETURNING *`,
            [
                apklausaId,
                klausimo_tekstas,
                a_variantas,
                b_variantas,
                c_variantas,
                d_variantas
            ]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// PUT /api/apklausos/:apklausaId/klausimai/:id
const updateKlausimas = async (req, res) => {
    try {
        const { apklausaId, id } = req.params;

        const {
            klausimo_tekstas,
            a_variantas,
            b_variantas,
            c_variantas,
            d_variantas
        } = req.body;

        if (
            !klausimo_tekstas ||
            !a_variantas ||
            !b_variantas ||
            !c_variantas ||
            !d_variantas
        ) {
            return res.status(422).json({
                error: 'Klausimo tekstas ir visi keturi variantai yra privalomi'
            });
        }

        const result = await pool.query(
            `UPDATE klausimas
             SET klausimo_tekstas = $1,
                 a_variantas = $2,
                 b_variantas = $3,
                 c_variantas = $4,
                 d_variantas = $5
             WHERE id = $6 AND apklausa_id = $7
             RETURNING *`,
            [
                klausimo_tekstas,
                a_variantas,
                b_variantas,
                c_variantas,
                d_variantas,
                id,
                apklausaId
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Klausimas nerastas'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// DELETE /api/apklausos/:apklausaId/klausimai/:id
const deleteKlausimas = async (req, res) => {
    try {
        const { apklausaId, id } = req.params;

        const result = await pool.query(
            `DELETE FROM klausimas
             WHERE id = $1 AND apklausa_id = $2
             RETURNING id`,
            [id, apklausaId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Klausimas nerastas'
            });
        }

        res.status(204).send();
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

module.exports = {
    getAllKlausimai,
    getKlausimasById,
    createKlausimas,
    updateKlausimas,
    deleteKlausimas
};