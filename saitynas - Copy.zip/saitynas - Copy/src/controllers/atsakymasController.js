const pool = require('../config/db');

// GET /api/klausimai/:klausimasId/atsakymai
const getAllAtsakymai = async (req, res) => {
    try {
        const { klausimasId } = req.params;

        const result = await pool.query(
            `SELECT *
             FROM atsakymas
             WHERE klausimas_id = $1
             ORDER BY id`,
            [klausimasId]
        );

        res.status(200).json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// GET /api/klausimai/:klausimasId/atsakymai/:id
const getAtsakymasById = async (req, res) => {
    try {
        const { klausimasId, id } = req.params;

        const result = await pool.query(
            `SELECT *
             FROM atsakymas
             WHERE id = $1 AND klausimas_id = $2`,
            [id, klausimasId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Atsakymas nerastas'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// POST /api/klausimai/:klausimasId/atsakymai
const createAtsakymas = async (req, res) => {
    try {
        const { klausimasId } = req.params;
        const { pasirinktas_variantas } = req.body;

        if (
            !Number.isInteger(pasirinktas_variantas) ||
            pasirinktas_variantas < 1 ||
            pasirinktas_variantas > 4
        ) {
            return res.status(422).json({
                error: 'Pasirinktas variantas turi būti skaičius nuo 1 iki 4'
            });
        }
        const klausimas = await pool.query(
            'SELECT id FROM klausimas WHERE id = $1',
            [klausimasId]
        );

        if (klausimas.rows.length === 0) {
            return res.status(404).json({
                error: 'Klausimas nerastas'
            });
        }

        const result = await pool.query(
            `INSERT INTO atsakymas
                (klausimas_id, pasirinktas_variantas)
             VALUES ($1, $2)
             RETURNING *`,
            [klausimasId, pasirinktas_variantas]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// PUT /api/klausimai/:klausimasId/atsakymai/:id
const updateAtsakymas = async (req, res) => {
    try {
        const { klausimasId, id } = req.params;
        const { pasirinktas_variantas } = req.body;

        if (
            !Number.isInteger(pasirinktas_variantas) ||
            pasirinktas_variantas < 1 ||
            pasirinktas_variantas > 4
        ) {
            return res.status(422).json({
                error: 'Pasirinktas variantas turi būti skaičius nuo 1 iki 4'
            });
        }

        const result = await pool.query(
            `UPDATE atsakymas
             SET pasirinktas_variantas = $1
             WHERE id = $2 AND klausimas_id = $3
             RETURNING *`,
            [pasirinktas_variantas, id, klausimasId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Atsakymas nerastas'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

// DELETE /api/klausimai/:klausimasId/atsakymai/:id
const deleteAtsakymas = async (req, res) => {
    try {
        const { klausimasId, id } = req.params;

        const result = await pool.query(
            `DELETE FROM atsakymas
             WHERE id = $1 AND klausimas_id = $2
             RETURNING id`,
            [id, klausimasId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Atsakymas nerastas'
            });
        }

        res.status(204).send();
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Serverio klaida' });
    }
};

module.exports = {
    getAllAtsakymai,
    getAtsakymasById,
    createAtsakymas,
    updateAtsakymas,
    deleteAtsakymas
};