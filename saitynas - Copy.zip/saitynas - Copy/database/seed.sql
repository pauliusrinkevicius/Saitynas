-- =========================================================
-- TYRIMAS - demonstraciniai duomenys
-- 10 apklausų
-- 50 klausimų
-- 1000 atsakymų
-- =========================================================

-- Išvalome ankstesnius testinius duomenis
-- ir ID vėl pradedame nuo 1.
TRUNCATE TABLE atsakymas, klausimas, apklausa
RESTART IDENTITY CASCADE;


-- =========================================================
-- APKLAUSOS
-- =========================================================

INSERT INTO apklausa (pavadinimas, aprasymas)
VALUES
    (
        'Programavimo kalbų apklausa',
        'Apklausa apie studentų naudojamas ir mėgstamas programavimo kalbas.'
    ),
    (
        'Studijų kokybės apklausa',
        'Apklausa apie studentų nuomonę apie studijų kokybę.'
    ),
    (
        'Nuotolinio mokymosi apklausa',
        'Apklausa apie studentų patirtį mokantis nuotoliniu būdu.'
    ),
    (
        'Dirbtinio intelekto naudojimas',
        'Apklausa apie dirbtinio intelekto įrankių naudojimą studijose.'
    ),
    (
        'Studentų laisvalaikis',
        'Apklausa apie studentų laisvalaikį ir pomėgius.'
    ),
    (
        'Transportas į universitetą',
        'Apklausa apie studentų naudojamas transporto priemones.'
    ),
    (
        'Darbas studijų metu',
        'Apklausa apie studentų darbą ir studijų derinimą.'
    ),
    (
        'Socialinių tinklų naudojimas',
        'Apklausa apie socialinių tinklų naudojimo įpročius.'
    ),
    (
        'Studentų mitybos įpročiai',
        'Apklausa apie studentų kasdienius mitybos pasirinkimus.'
    ),
    (
        'Karjeros planai',
        'Apklausa apie studentų planus po studijų.'
    );


-- =========================================================
-- 1 APKLAUSA
-- Programavimo kalbų apklausa
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        1,
        'Kokia programavimo kalba jums labiausiai patinka?',
        'Python',
        'Java',
        'C++',
        'JavaScript'
    ),
    (
        1,
        'Kurią programavimo kalbą naudojate dažniausiai?',
        'Python',
        'Java',
        'C++',
        'JavaScript'
    ),
    (
        1,
        'Kokią programavimo kalbą išmokote pirmiausia?',
        'Python',
        'C++',
        'Java',
        'JavaScript'
    ),
    (
        1,
        'Kuri programavimo kalba jums atrodo sunkiausia?',
        'Python',
        'Java',
        'C++',
        'JavaScript'
    ),
    (
        1,
        'Kokią programavimo kalbą norėtumėte geriau išmokti?',
        'Python',
        'Java',
        'C++',
        'JavaScript'
    );


-- =========================================================
-- 2 APKLAUSA
-- Studijų kokybė
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        2,
        'Kaip vertinate bendrą studijų kokybę?',
        'Labai gerai',
        'Gerai',
        'Vidutiniškai',
        'Blogai'
    ),
    (
        2,
        'Kaip vertinate dėstytojų komunikaciją?',
        'Labai gerai',
        'Gerai',
        'Vidutiniškai',
        'Blogai'
    ),
    (
        2,
        'Kaip vertinate pateikiamą studijų medžiagą?',
        'Labai gerai',
        'Gerai',
        'Vidutiniškai',
        'Blogai'
    ),
    (
        2,
        'Kaip vertinate praktinių darbų naudingumą?',
        'Labai naudingi',
        'Naudingi',
        'Vidutiniškai naudingi',
        'Nenaudingi'
    ),
    (
        2,
        'Ar rekomenduotumėte savo studijų programą kitiems?',
        'Tikrai taip',
        'Greičiausiai taip',
        'Greičiausiai ne',
        'Tikrai ne'
    );


-- =========================================================
-- 3 APKLAUSA
-- Nuotolinis mokymasis
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        3,
        'Kaip dažnai dalyvaujate nuotolinėse paskaitose?',
        'Kasdien',
        'Kelis kartus per savaitę',
        'Retai',
        'Niekada'
    ),
    (
        3,
        'Kaip vertinate nuotolinių paskaitų kokybę?',
        'Labai gerai',
        'Gerai',
        'Vidutiniškai',
        'Blogai'
    ),
    (
        3,
        'Kur jums lengviau susikaupti?',
        'Namuose',
        'Universitete',
        'Bibliotekoje',
        'Kitur'
    ),
    (
        3,
        'Kokį mokymosi būdą renkatės?',
        'Nuotolinį',
        'Kontaktinį',
        'Mišrų',
        'Neturiu nuomonės'
    ),
    (
        3,
        'Ar nuotolinis mokymas taupo jūsų laiką?',
        'Labai',
        'Šiek tiek',
        'Beveik ne',
        'Visai ne'
    );


-- =========================================================
-- 4 APKLAUSA
-- Dirbtinis intelektas
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        4,
        'Kaip dažnai naudojate dirbtinio intelekto įrankius?',
        'Kasdien',
        'Kelis kartus per savaitę',
        'Retai',
        'Niekada'
    ),
    (
        4,
        'Kam dažniausiai naudojate dirbtinį intelektą?',
        'Programavimui',
        'Tekstų rašymui',
        'Informacijos paieškai',
        'Nenaudoju'
    ),
    (
        4,
        'Ar dirbtinis intelektas padeda mokytis?',
        'Labai padeda',
        'Šiek tiek padeda',
        'Beveik nepadeda',
        'Visai nepadeda'
    ),
    (
        4,
        'Ar tikrinate dirbtinio intelekto pateiktą informaciją?',
        'Visada',
        'Dažniausiai',
        'Retai',
        'Niekada'
    ),
    (
        4,
        'Kaip vertinate dirbtinio intelekto naudojimą universitete?',
        'Labai teigiamai',
        'Teigiamai',
        'Neutraliai',
        'Neigiamai'
    );


-- =========================================================
-- 5 APKLAUSA
-- Laisvalaikis
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        5,
        'Kaip dažniausiai leidžiate laisvalaikį?',
        'Sportuoju',
        'Žaidžiu žaidimus',
        'Susitinku su draugais',
        'Žiūriu filmus ar serialus'
    ),
    (
        5,
        'Kiek valandų per dieną skiriate laisvalaikiui?',
        'Mažiau nei 1 val.',
        '1-2 val.',
        '2-4 val.',
        'Daugiau nei 4 val.'
    ),
    (
        5,
        'Kaip dažnai sportuojate?',
        'Kasdien',
        '3-4 kartus per savaitę',
        '1-2 kartus per savaitę',
        'Nesportuoju'
    ),
    (
        5,
        'Kaip dažnai žaidžiate kompiuterinius žaidimus?',
        'Kasdien',
        'Kelis kartus per savaitę',
        'Retai',
        'Niekada'
    ),
    (
        5,
        'Kur dažniausiai leidžiate savaitgalius?',
        'Namuose',
        'Su draugais',
        'Gamtoje',
        'Keliauju'
    );


-- =========================================================
-- 6 APKLAUSA
-- Transportas
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        6,
        'Kaip dažniausiai vykstate į universitetą?',
        'Automobiliu',
        'Viešuoju transportu',
        'Dviračiu',
        'Pėsčiomis'
    ),
    (
        6,
        'Kiek laiko užtrunka kelionė į universitetą?',
        'Iki 15 min.',
        '15-30 min.',
        '30-60 min.',
        'Daugiau nei 60 min.'
    ),
    (
        6,
        'Kaip vertinate viešąjį transportą?',
        'Labai gerai',
        'Gerai',
        'Vidutiniškai',
        'Blogai'
    ),
    (
        6,
        'Kas svarbiausia renkantis transportą?',
        'Kaina',
        'Greitis',
        'Patogumas',
        'Ekologiškumas'
    ),
    (
        6,
        'Ar norėtumėte dažniau naudoti viešąjį transportą?',
        'Tikrai taip',
        'Greičiausiai taip',
        'Greičiausiai ne',
        'Tikrai ne'
    );


-- =========================================================
-- 7 APKLAUSA
-- Darbas studijų metu
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        7,
        'Ar šiuo metu dirbate?',
        'Taip, pilnu etatu',
        'Taip, daliniu etatu',
        'Dirbu retkarčiais',
        'Nedirbu'
    ),
    (
        7,
        'Kiek valandų per savaitę dirbate?',
        'Iki 10 val.',
        '10-20 val.',
        '20-30 val.',
        'Daugiau nei 30 val.'
    ),
    (
        7,
        'Ar lengva suderinti darbą ir studijas?',
        'Labai lengva',
        'Pakankamai lengva',
        'Sunku',
        'Labai sunku'
    ),
    (
        7,
        'Kodėl dirbate studijų metu?',
        'Dėl pajamų',
        'Dėl patirties',
        'Dėl karjeros',
        'Kita priežastis'
    ),
    (
        7,
        'Ar jūsų darbas susijęs su studijų programa?',
        'Visiškai susijęs',
        'Iš dalies susijęs',
        'Beveik nesusijęs',
        'Visai nesusijęs'
    );


-- =========================================================
-- 8 APKLAUSA
-- Socialiniai tinklai
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        8,
        'Kurį socialinį tinklą naudojate dažniausiai?',
        'Instagram',
        'TikTok',
        'Facebook',
        'X'
    ),
    (
        8,
        'Kiek laiko per dieną praleidžiate socialiniuose tinkluose?',
        'Iki 1 val.',
        '1-2 val.',
        '2-4 val.',
        'Daugiau nei 4 val.'
    ),
    (
        8,
        'Kam dažniausiai naudojate socialinius tinklus?',
        'Bendravimui',
        'Pramogoms',
        'Naujienoms',
        'Mokslui'
    ),
    (
        8,
        'Ar socialiniai tinklai trukdo mokytis?',
        'Labai',
        'Kartais',
        'Retai',
        'Visai netrukdo'
    ),
    (
        8,
        'Ar bandote riboti laiką socialiniuose tinkluose?',
        'Taip, visada',
        'Kartais',
        'Retai',
        'Niekada'
    );


-- =========================================================
-- 9 APKLAUSA
-- Mityba
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        9,
        'Kaip dažnai valgote pusryčius?',
        'Kasdien',
        'Dažnai',
        'Retai',
        'Niekada'
    ),
    (
        9,
        'Kur dažniausiai pietaujate?',
        'Namuose',
        'Universitete',
        'Restorane ar kavinėje',
        'Nevalgau pietų'
    ),
    (
        9,
        'Kaip dažnai gaminate maistą namuose?',
        'Kasdien',
        'Kelis kartus per savaitę',
        'Retai',
        'Niekada'
    ),
    (
        9,
        'Kas svarbiausia renkantis maistą?',
        'Kaina',
        'Skonis',
        'Sveikumas',
        'Paruošimo greitis'
    ),
    (
        9,
        'Kaip vertinate savo mitybos įpročius?',
        'Labai gerai',
        'Gerai',
        'Vidutiniškai',
        'Blogai'
    );


-- =========================================================
-- 10 APKLAUSA
-- Karjeros planai
-- =========================================================

INSERT INTO klausimas
(apklausa_id, klausimo_tekstas, a_variantas, b_variantas, c_variantas, d_variantas)
VALUES
    (
        10,
        'Ką planuojate veikti baigę studijas?',
        'Dirbti Lietuvoje',
        'Dirbti užsienyje',
        'Tęsti studijas',
        'Dar nežinau'
    ),
    (
        10,
        'Kokioje srityje norėtumėte dirbti?',
        'Programavime',
        'Duomenų analizėje',
        'Projektų valdyme',
        'Kitoje srityje'
    ),
    (
        10,
        'Kas svarbiausia renkantis darbą?',
        'Atlyginimas',
        'Karjeros galimybės',
        'Darbo aplinka',
        'Lankstumas'
    ),
    (
        10,
        'Kokį darbo modelį rinktumėtės?',
        'Biure',
        'Nuotolinį',
        'Hibridinį',
        'Neturiu preference'
    ),
    (
        10,
        'Ar planuojate dirbti pagal įgytą specialybę?',
        'Tikrai taip',
        'Greičiausiai taip',
        'Greičiausiai ne',
        'Tikrai ne'
    );


-- =========================================================
-- ATSAKYMAI
-- Sukuriame po 20 atsakymų kiekvienam iš 50 klausimų.
--
-- 50 klausimų * 20 atsakymų = 1000 atsakymų.
-- =========================================================

INSERT INTO atsakymas (klausimas_id, pasirinktas_variantas)
SELECT
    k.id,
    ((k.id + g.nr) % 4) + 1
FROM klausimas k
    CROSS JOIN generate_series(1, 20) AS g(nr);


-- =========================================================
-- PATIKRINIMAS
-- =========================================================

SELECT COUNT(*) AS apklausu_kiekis
FROM apklausa;

SELECT COUNT(*) AS klausimu_kiekis
FROM klausimas;

SELECT COUNT(*) AS atsakymu_kiekis
FROM atsakymas;
TRUNCATE TABLE atsakymas, klausimas, apklausa
RESTART IDENTITY CASCADE;