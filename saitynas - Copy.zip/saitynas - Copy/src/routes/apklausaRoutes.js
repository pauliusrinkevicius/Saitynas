const express = require('express');
const router = express.Router();

const {
    getAllApklausos,
    getApklausaById,
    createApklausa,
    updateApklausa,
    deleteApklausa
} = require('../controllers/apklausaController');

/**
 * @swagger
 * tags:
 *   name: Apklausos
 *   description: Apklausų valdymas
 */

/**
 * @swagger
 * /api/apklausos:
 *   get:
 *     summary: Gauti visas apklausas
 *     tags: [Apklausos]
 *     responses:
 *       200:
 *         description: Apklausų sąrašas
 */
router.get('/', getAllApklausos);

/**
 * @swagger
 * /api/apklausos/{id}:
 *   get:
 *     summary: Gauti apklausą pagal ID
 *     tags: [Apklausos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Apklausos ID
 *     responses:
 *       200:
 *         description: Apklausos duomenys
 *       404:
 *         description: Apklausa nerasta
 */
router.get('/:id', getApklausaById);

/**
 * @swagger
 * /api/apklausos:
 *   post:
 *     summary: Sukurti naują apklausą
 *     tags: [Apklausos]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - pavadinimas
 *             properties:
 *               pavadinimas:
 *                 type: string
 *                 example: Programavimo kalbų apklausa
 *               aprasymas:
 *                 type: string
 *                 example: Apklausa apie mėgstamas programavimo kalbas
 *     responses:
 *       201:
 *         description: Apklausa sėkmingai sukurta
 *       422:
 *         description: Neteisingi apklausos duomenys
 */
router.post('/', createApklausa);

/**
 * @swagger
 * /api/apklausos/{id}:
 *   put:
 *     summary: Atnaujinti apklausą
 *     tags: [Apklausos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Apklausos ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - pavadinimas
 *             properties:
 *               pavadinimas:
 *                 type: string
 *                 example: Atnaujinta apklausa
 *               aprasymas:
 *                 type: string
 *                 example: Atnaujintas apklausos aprašymas
 *     responses:
 *       200:
 *         description: Apklausa sėkmingai atnaujinta
 *       404:
 *         description: Apklausa nerasta
 *       422:
 *         description: Neteisingi apklausos duomenys
 */
router.put('/:id', updateApklausa);

/**
 * @swagger
 * /api/apklausos/{id}:
 *   delete:
 *     summary: Ištrinti apklausą
 *     tags: [Apklausos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Apklausos ID
 *     responses:
 *       204:
 *         description: Apklausa sėkmingai ištrinta
 *       404:
 *         description: Apklausa nerasta
 */
router.delete('/:id', deleteApklausa);

module.exports = router;