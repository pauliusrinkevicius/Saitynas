const { Pool } = require('pg');

// Load local environment variables from .env during development.
require('dotenv').config();

// PostgreSQL credentials are provided through environment variables.
const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

module.exports = pool;
