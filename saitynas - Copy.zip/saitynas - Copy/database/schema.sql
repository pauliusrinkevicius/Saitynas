CREATE TABLE apklausa (
                          id SERIAL PRIMARY KEY,
                          pavadinimas VARCHAR(255) NOT NULL,
                          aprasymas TEXT,
                          sukurta TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE klausimas (
                           id SERIAL PRIMARY KEY,
                           apklausa_id INTEGER NOT NULL,
                           klausimo_tekstas TEXT NOT NULL,
                           a_variantas VARCHAR(255) NOT NULL,
                           b_variantas VARCHAR(255) NOT NULL,
                           c_variantas VARCHAR(255) NOT NULL,
                           d_variantas VARCHAR(255) NOT NULL,

                           FOREIGN KEY (apklausa_id)
                               REFERENCES apklausa(id)
                               ON DELETE CASCADE
);

CREATE TABLE atsakymas (
                           id SERIAL PRIMARY KEY,
                           klausimas_id INTEGER NOT NULL,
                           pasirinktas_variantas INTEGER NOT NULL,
                           pateikta TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

                           FOREIGN KEY (klausimas_id)
                               REFERENCES klausimas(id)
                               ON DELETE CASCADE,

                           CHECK (pasirinktas_variantas BETWEEN 1 AND 4)
);