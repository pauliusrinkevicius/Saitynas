const express = require('express');
const router = express.Router({ mergeParams: true });

const {
    getAllKlausimai,
    getKlausimasById,
    createKlausimas,
    updateKlausimas,
    deleteKlausimas
} = require('../controllers/klausimasController');

/**
 * @swagger
 * tags:
 *   name: Klausimai
 *   description: Apklausų klausimų valdymas
 */

/**
 * @swagger
 * /api/apklausos/{apklausaId}/klausimai:
 *   get:
 *     summary: Gauti visus apklausos klausimus
 *     tags: [Klausimai]
 *     parameters:
 *       - in: path
 *         name: apklausaId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Apklausos ID
 *     responses:
 *       200:
 *         description: Klausimų sąrašas
 */
router.get('/', getAllKlausimai);

/**
 * @swagger
 * /api/apklausos/{apklausaId}/klausimai/{id}:
 *   get:
 *     summary: Gauti klausimą pagal ID
 *     tags: [Klausimai]
 *     parameters:
 *       - in: path
 *         name: apklausaId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Klausimo duomenys
 *       404:
 *         description: Klausimas nerastas
 */
router.get('/:id', getKlausimasById);

/**
 * @swagger
 * /api/apklausos/{apklausaId}/klausimai:
 *   post:
 *     summary: Sukurti naują klausimą
 *     tags: [Klausimai]
 *     parameters:
 *       - in: path
 *         name: apklausaId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Apklausos ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - klausimo_tekstas
 *               - a_variantas
 *               - b_variantas
 *               - c_variantas
 *               - d_variantas
 *             properties:
 *               klausimo_tekstas:
 *                 type: string
 *                 example: Kokia programavimo kalba jums labiausiai patinka?
 *               a_variantas:
 *                 type: string
 *                 example: Python
 *               b_variantas:
 *                 type: string
 *                 example: Java
 *               c_variantas:
 *                 type: string
 *                 example: C++
 *               d_variantas:
 *                 type: string
 *                 example: JavaScript
 *     responses:
 *       201:
 *         description: Klausimas sėkmingai sukurtas
 *       404:
 *         description: Apklausa nerasta
 *       422:
 *         description: Neteisingi klausimo duomenys
 */
router.post('/', createKlausimas);

/**
 * @swagger
 * /api/apklausos/{apklausaId}/klausimai/{id}:
 *   put:
 *     summary: Atnaujinti klausimą
 *     tags: [Klausimai]
 *     parameters:
 *       - in: path
 *         name: apklausaId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - klausimo_tekstas
 *               - a_variantas
 *               - b_variantas
 *               - c_variantas
 *               - d_variantas
 *             properties:
 *               klausimo_tekstas:
 *                 type: string
 *                 example: Kurią programavimo kalbą naudojate dažniausiai?
 *               a_variantas:
 *                 type: string
 *                 example: Python
 *               b_variantas:
 *                 type: string
 *                 example: Java
 *               c_variantas:
 *                 type: string
 *                 example: C++
 *               d_variantas:
 *                 type: string
 *                 example: JavaScript
 *     responses:
 *       200:
 *         description: Klausimas sėkmingai atnaujintas
 *       404:
 *         description: Klausimas nerastas
 *       422:
 *         description: Neteisingi klausimo duomenys
 */
router.put('/:id', updateKlausimas);

/**
 * @swagger
 * /api/apklausos/{apklausaId}/klausimai/{id}:
 *   delete:
 *     summary: Ištrinti klausimą
 *     tags: [Klausimai]
 *     parameters:
 *       - in: path
 *         name: apklausaId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       204:
 *         description: Klausimas sėkmingai ištrintas
 *       404:
 *         description: Klausimas nerastas
 */
router.delete('/:id', deleteKlausimas);

module.exports = router;