const express = require('express');
const router = express.Router({ mergeParams: true });

const {
    getAllAtsakymai,
    getAtsakymasById,
    createAtsakymas,
    updateAtsakymas,
    deleteAtsakymas
} = require('../controllers/atsakymasController');

/**
 * @swagger
 * tags:
 *   name: Atsakymai
 *   description: Klausimų atsakymų valdymas
 */

/**
 * @swagger
 * /api/klausimai/{klausimasId}/atsakymai:
 *   get:
 *     summary: Gauti visus klausimo atsakymus
 *     tags: [Atsakymai]
 *     parameters:
 *       - in: path
 *         name: klausimasId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Klausimo ID
 *     responses:
 *       200:
 *         description: Atsakymų sąrašas
 */
router.get('/', getAllAtsakymai);

/**
 * @swagger
 * /api/klausimai/{klausimasId}/atsakymai/{id}:
 *   get:
 *     summary: Gauti atsakymą pagal ID
 *     tags: [Atsakymai]
 *     parameters:
 *       - in: path
 *         name: klausimasId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Atsakymo duomenys
 *       404:
 *         description: Atsakymas nerastas
 */
router.get('/:id', getAtsakymasById);

/**
 * @swagger
 * /api/klausimai/{klausimasId}/atsakymai:
 *   post:
 *     summary: Sukurti naują atsakymą
 *     tags: [Atsakymai]
 *     parameters:
 *       - in: path
 *         name: klausimasId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Klausimo ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - pasirinktas_variantas
 *             properties:
 *               pasirinktas_variantas:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 4
 *                 example: 2
 *                 description: 1 = A, 2 = B, 3 = C, 4 = D
 *     responses:
 *       201:
 *         description: Atsakymas sėkmingai sukurtas
 *       404:
 *         description: Klausimas nerastas
 *       422:
 *         description: Neteisingi atsakymo duomenys
 */
router.post('/', createAtsakymas);

/**
 * @swagger
 * /api/klausimai/{klausimasId}/atsakymai/{id}:
 *   put:
 *     summary: Atnaujinti atsakymą
 *     tags: [Atsakymai]
 *     parameters:
 *       - in: path
 *         name: klausimasId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - pasirinktas_variantas
 *             properties:
 *               pasirinktas_variantas:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 4
 *                 example: 3
 *                 description: 1 = A, 2 = B, 3 = C, 4 = D
 *     responses:
 *       200:
 *         description: Atsakymas sėkmingai atnaujintas
 *       404:
 *         description: Atsakymas nerastas
 *       422:
 *         description: Neteisingi atsakymo duomenys
 */
router.put('/:id', updateAtsakymas);

/**
 * @swagger
 * /api/klausimai/{klausimasId}/atsakymai/{id}:
 *   delete:
 *     summary: Ištrinti atsakymą
 *     tags: [Atsakymai]
 *     parameters:
 *       - in: path
 *         name: klausimasId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       204:
 *         description: Atsakymas sėkmingai ištrintas
 *       404:
 *         description: Atsakymas nerastas
 */
router.delete('/:id', deleteAtsakymas);

module.exports = router;