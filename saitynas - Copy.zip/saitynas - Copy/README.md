# Tyrimas REST API

Initial backend setup for the Tyrimas university REST API project. The API uses
Node.js, Express, and PostgreSQL with raw SQL queries.

## Requirements

- Node.js and npm
- PostgreSQL

## Setup

Install project dependencies:

```bash
npm install
```

Copy `.env.example` to `.env` and update the database settings to match your
local PostgreSQL installation. Create a PostgreSQL database named `tyrimas_db`
or change `DB_NAME` to an existing database.

## Run

Start the API in development mode with automatic restarts:

```bash
npm run dev
```

Or start it normally:

```bash
npm start
```

The server uses port `3000` by default. Set `PORT` in `.env` to use another
port.

## Test endpoints

With the server running, open these URLs in a browser or send GET requests with
curl:

```bash
curl http://localhost:3000/
curl http://localhost:3000/api/test-db
```

`GET /` returns the API status message. `GET /api/test-db` runs `SELECT NOW()`
and returns the PostgreSQL server time; it returns HTTP 500 if the database
connection fails.

## Database files

`database/schema.sql` and `database/seed.sql` are placeholders for future
database setup. No domain tables are created yet.
