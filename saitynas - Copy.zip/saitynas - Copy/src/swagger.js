const swaggerJsdoc = require('swagger-jsdoc');

const options = {
    definition: {
        openapi: '3.0.0',

        info: {
            title: 'Tyrimas REST API',
            version: '1.0.0',
            description: 'REST API apklausų, klausimų ir atsakymų valdymui'
        },

        servers: [
            {
                url: 'http://localhost:3000',
                description: 'Lokalus serveris'
            }
        ]
    },

    apis: ['./src/routes/*.js']
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = swaggerSpec;